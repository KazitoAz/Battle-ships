﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MyGame
{
    public enum ShipName
    {
        None = 0,
        Tug = 1,
        Submarine = 2,
        Destroyer = 3,
        Battleship = 4,
        AircraftCarrier = 5
    }
}
